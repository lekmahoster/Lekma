from Classes.Logic.LogicCommandManager import LogicCommandManager
from Classes.Packets.PiranhaMessage import PiranhaMessage


class AvailableServerCommandMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        self.writeVInt(203) # Command
        self.writeVInt(0)
        self.writeVInt(1) # Multipler
        self.writeVInt(10) # Box ID
        self.writeVInt(1) # Reward Count

        self.writeVInt(800) # Value
        self.writeVInt(0) # ScId
        self.writeVInt(7) # Reward ID
        self.writeDataReference(0, 0) # ScId
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24111

    def getMessageVersion(self):
        return self.messageVersion